def hello():
    print('hello from mod1')